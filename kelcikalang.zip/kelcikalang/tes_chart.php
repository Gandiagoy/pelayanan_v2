        <script src="js/amcharts.js" type="text/javascript"></script>        
        <script type="text/javascript">
            var chart;
            var legend;

            var chartData = [{
                country: "Korea",
                value: 260
            }, {
                country: "Jepang",
                value: 201
            }, {
                country: "Mexico",
                value: 65
            }, {
                country: "Rusia",
                value: 39
            }, {
                country: "Amerika",
                value: 19
            }, {
                country: "Brazil",
                value: 10
            }];

            AmCharts.ready(function () {
                // PIE CHART
                chart = new AmCharts.AmPieChart();
                chart.dataProvider = chartData;
                chart.titleField = "country";
                chart.valueField = "value";
                chart.outlineColor = "#FFFFFF";
                chart.outlineAlpha = 0.8;
                chart.outlineThickness = 2;
                // this makes the chart 3D
                chart.depth3D = 15;
                chart.angle = 30;

                // WRITE
                chart.write("chartdiv");
            });
        </script>
    
        <div id="chartdiv" style="width: 100%; height: 400px;"></div>

